// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("include what you use\n", stdout);
  return lionss_run_workload("include-what-you-use");
}
