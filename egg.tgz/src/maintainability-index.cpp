// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("maintainability index\n", stdout);
  return lionss_run_workload("maintainability-index");
}
