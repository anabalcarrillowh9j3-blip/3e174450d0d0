// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("docs examples"); }
int main(){
  announce();
  return lionss_run_workload("docs-examples");
}
