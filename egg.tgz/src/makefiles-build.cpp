// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("makefiles build"); }
int main(){
  announce();
  return lionss_run_workload("makefiles-build");
}
