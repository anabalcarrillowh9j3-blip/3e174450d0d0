// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "in source guard");
  std::fflush(stdout);
  return lionss_run_workload("in-source-guard");
}
