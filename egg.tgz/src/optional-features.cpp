// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("optional features\n", stdout);
  return lionss_run_workload("optional-features");
}
